<?php
require_once __DIR__ . '/../db.php';
include __DIR__ . '/../partials/admin_header.php';

$pdo = connect();

// 🔸 取得縣市清單
$regionStmt = $pdo->query("SELECT id, name FROM regions ORDER BY id ASC");
$regions = $regionStmt->fetchAll(PDO::FETCH_KEY_PAIR);

// 🔸 1. 新申請等待審核的店家
$pendingStmt = $pdo->query("SELECT * FROM stores WHERE status = 0 ORDER BY created_at DESC");
$pendingStores = $pendingStmt->fetchAll();

// 🔸 2. VIP 店家尚未下單
$vipNoOrderStmt = $pdo->query("
    SELECT * FROM stores
    WHERE status = 1 AND type = 'vip' AND order_count = 0
    ORDER BY created_at DESC
");
$vipNoOrderStores = $vipNoOrderStmt->fetchAll();

// 🔸 3. 各縣市店家分布統計
$regionStatsStmt = $pdo->query("
    SELECT r.name AS region_name, COUNT(s.id) AS store_count
    FROM stores s
    JOIN regions r ON r.id = s.region_id
    GROUP BY s.region_id
    ORDER BY store_count DESC
");
$regionStats = $regionStatsStmt->fetchAll(PDO::FETCH_ASSOC);

// 🔸 4. 最近沒有下單的 VIP 店家（超過90天未下單）
$inactiveVipStmt = $pdo->query("
    SELECT * FROM stores
    WHERE status = 1 AND type = 'vip'
      AND (last_order_at IS NULL OR last_order_at < NOW() - INTERVAL 90 DAY)
    ORDER BY last_order_at ASC
");
$inactiveVipStores = $inactiveVipStmt->fetchAll();

// 🔸 5. 活躍 VIP 店家排行榜（依下單次數排序）
$topVipStmt = $pdo->query("
    SELECT * FROM stores
    WHERE status = 1 AND type = 'vip'
    ORDER BY order_count DESC, last_order_at DESC
    LIMIT 10
");
$topVipStores = $topVipStmt->fetchAll();
?>

<div class="container py-4">
  <h3 class="mb-4">店家管理總覽</h3>

  <!-- 新申請等待審核的店家 -->
  <div class="mb-4">
    <h5>🔸 待審核申請</h5>
    <?php if ($pendingStores): ?>
      <ul>
        <?php foreach ($pendingStores as $store): ?>
          <li><?= htmlspecialchars($store['name']) ?>（<?= $regions[$store['region_id']] ?? '' ?>）</li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="text-muted">目前沒有待審核的店家。</p>
    <?php endif; ?>
  </div>

  <!-- VIP 店家尚未下單 -->
  <div class="mb-4">
    <h5>🔸 VIP 店家尚未下單</h5>
    <?php if ($vipNoOrderStores): ?>
      <ul>
        <?php foreach ($vipNoOrderStores as $store): ?>
          <li><?= htmlspecialchars($store['name']) ?>（<?= $regions[$store['region_id']] ?? '' ?>）</li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="text-muted">目前所有 VIP 店家皆有下單紀錄。</p>
    <?php endif; ?>
  </div>

  <!-- 各縣市店家分布 -->
  <div class="mb-4">
    <h5>🔸 店家區域分布統計</h5>
    <ul>
      <?php foreach ($regionStats as $r): ?>
        <li><?= htmlspecialchars($r['region_name']) ?>：<?= $r['store_count'] ?> 家</li>
      <?php endforeach; ?>
    </ul>
  </div>

  <!-- 最近未下單的 VIP 店家 -->
  <div class="mb-4">
    <h5>🔸 長時間未下單的 VIP 店家</h5>
    <?php if ($inactiveVipStores): ?>
      <ul>
        <?php foreach ($inactiveVipStores as $store): ?>
          <li><?= htmlspecialchars($store['name']) ?>（<?= $regions[$store['region_id']] ?? '' ?>） - 最後下單：<?= $store['last_order_at'] ?: '無紀錄' ?></li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="text-muted">目前沒有超過 90 天未下單的 VIP 店家。</p>
    <?php endif; ?>
  </div>

  <!-- 活躍 VIP 店家排行榜 -->
  <div class="mb-4">
    <h5>🔸 活躍 VIP 店家（依下單次數）</h5>
    <?php if ($topVipStores): ?>
      <ol>
        <?php foreach ($topVipStores as $store): ?>
          <li><?= htmlspecialchars($store['name']) ?>（<?= $regions[$store['region_id']] ?? '' ?>） - 下單 <?= $store['order_count'] ?> 次</li>
        <?php endforeach; ?>
      </ol>
    <?php else: ?>
      <p class="text-muted">暫無活躍店家。</p>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/../partials/admin_footer.php'; ?>