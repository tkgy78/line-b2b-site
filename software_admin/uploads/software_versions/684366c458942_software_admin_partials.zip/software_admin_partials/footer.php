<?php
// software_admin/partials/footer.php
?>
<footer class="text-center py-4 text-muted">
  <hr>
  <small>© <?= date('Y') ?> 調音軟體管理系統</small>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
