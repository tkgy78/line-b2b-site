<?php
// header.php - placeholder file
?>